package savi.asu.picknpack;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by srisa on 5/8/2017.
 */

public class SubActivity extends AppCompatActivity{

    private List<Cat_item> myItem = new ArrayList<Cat_item>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);
        if(getSupportActionBar()!=null)
        {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        populateItemList();
        populateListView();
        registerClickCallback();
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home)
            startActivity(new Intent(this,MainActivity.class));
        return super.onOptionsItemSelected(item);
    }
    private void populateItemList() {
        myItem.add(new Cat_item("Vegetable", R.drawable.vegi));
        myItem.add(new Cat_item("Fruits", R.drawable.fruits));
        myItem.add(new Cat_item("Milk", R.drawable.milk));
        myItem.add(new Cat_item("Drinks", R.drawable.drinks));
        myItem.add(new Cat_item("Bread", R.drawable.bread));
        myItem.add(new Cat_item("Meat" , R.drawable.meat));
    }

    private void populateListView() {
        ArrayAdapter<Cat_item> adapter = new MyListAdapter();
        ListView list = (ListView) findViewById(R.id.catListView);
        list.setAdapter(adapter);
    }

    private void registerClickCallback() {
        ListView list = (ListView) findViewById(R.id.catListView);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View viewClicked,
                                    int position, long id) {

                Cat_item clickedCar = myItem.get(position);
                String message = "You clicked position " + (position + 1)
                        + " Which is Item " + clickedCar.getName();
                Toast.makeText(SubActivity.this, message, Toast.LENGTH_LONG).show();
                Intent myIntent = new Intent(viewClicked.getContext(), SubActivity1.class);
                startActivityForResult(myIntent, 0);
            }
        });
    }

    private class MyListAdapter extends ArrayAdapter<Cat_item> {
        public MyListAdapter() {
            super(SubActivity.this, R.layout.cat_list, myItem);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Make sure we have a view to work with (may have been given null)
            View itemView = convertView;
            if (itemView == null) {
                itemView = getLayoutInflater().inflate(R.layout.cat_list, parent, false);

            }
            //View mView = getLayoutInflater().inflate(R.layout.item_view,null);

            // Find the car to work with.
            Cat_item currentCar = myItem.get(position);

            // Fill the view
            ImageView imageView = (ImageView)itemView.findViewById(R.id.cat_icon);
            imageView.setImageResource(currentCar.getIconID());

            // Make:
            TextView makeText = (TextView) itemView.findViewById(R.id.cat_name);
            makeText.setText(currentCar.getName());

            return itemView;
        }
    }
}
