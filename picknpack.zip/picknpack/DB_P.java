package savi.asu.picknpack;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by srisa on 5/12/2017.
 */

public class DB_P extends AppCompatActivity {

    ImageView Im;
    TextView tv_name, tv_items, tv_directions;
    int msg_im;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resep);

        Intent iIdentify = getIntent();
        msg_im = iIdentify.getIntExtra("dataIM", 0);
        String msg_name = iIdentify.getStringExtra("dataName");
        String msg_items = iIdentify.getStringExtra("dataItems");
        String msg_directions= iIdentify.getStringExtra("dataDirections");
        Im = (ImageView) findViewById(R.id.iv_detail);
        tv_name = (TextView) findViewById(R.id.tvName);
        tv_items = (TextView) findViewById(R.id.tvItems);
        tv_directions= (TextView) findViewById(R.id.tvDirections);
        Im.setImageResource(msg_im);
        tv_name.setText(msg_name);
        tv_items.setText(msg_items);
        tv_directions.setText(msg_directions);
    }
}

