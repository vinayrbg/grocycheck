package savi.asu.picknpack;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by srisa on 5/8/2017.
 */

public class SubActivity1 extends AppCompatActivity

{
    private List<Cat_item> myItem = new ArrayList<Cat_item>();
    public static List<Collect_Data> myItem1 = new ArrayList<>();
    // Collect_Data [] c1 = new Collect_Data[20];
    Collect_Data  c2 ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_item_main);
        if(getSupportActionBar()!=null)
        {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        Button cout = (Button) findViewById(R.id.checkout);

        cout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), Checkout_Activity.class);
                startActivityForResult(myIntent, 0);
            }
        });
        populateItemList();
        populateListView();
        registerClickCallback();
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home)
            startActivity(new Intent(this, SubActivity.class));
        return super.onOptionsItemSelected(item);
    }
    private void populateItemList() {
        myItem.add(new Cat_item("Carrot", R.drawable.vegi));
        myItem.add(new Cat_item("Beans", R.drawable.beans));
        myItem.add(new Cat_item("Potato", R.drawable.potato));
        myItem.add(new Cat_item("Tomato", R.drawable.tomato));
        myItem.add(new Cat_item("Mushroom", R.drawable.mushroom));
        myItem.add(new Cat_item("Okra", R.drawable.okra));
        myItem.add(new Cat_item("Cauli Flower", R.drawable.cauli));
        myItem.add(new Cat_item("Broccoli", R.drawable.broccoli));
        myItem.add(new Cat_item("Egg plant", R.drawable.eggplant));
    }

    private void populateListView() {
        ArrayAdapter<Cat_item> adapter = new MyListAdapter();
        ListView list = (ListView) findViewById(R.id.ItemListView);
        list.setAdapter(adapter);
    }

    private void registerClickCallback() {
        ListView list = (ListView) findViewById(R.id.ItemListView);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View viewClicked,
                                    int position, long id) {

                Cat_item clickedCar = myItem.get(position);
                String message = "You clicked position " + (position + 1)
                        + " Which is Item " + clickedCar.getName();
                Toast.makeText(SubActivity1.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private class MyListAdapter extends ArrayAdapter<Cat_item> {
        public MyListAdapter() {
            super(SubActivity1.this, R.layout.item_list, myItem);

        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Make sure we have a view to work with (may have been given null)
            View itemView = convertView;
            if (itemView == null) {
                itemView = getLayoutInflater().inflate(R.layout.item_list, parent, false);

            }
            //View mView = getLayoutInflater().inflate(R.layout.item_view,null);
            final EditText mCount = (EditText) itemView.findViewById(R.id.count);
            Button mPlus = (Button) itemView.findViewById(R.id.bt_plus);
            Button mMinus = (Button) itemView.findViewById(R.id.bt_minus);
            final Cat_item clickedCar = myItem.get(position);
            final int pns = position;
            c2 = new Collect_Data();

            mMinus.setOnClickListener(new View.OnClickListener()
            {
                public void onClick (View view)
                {
                    int myMCount = Integer.parseInt(mCount.getText().toString());
                    String mysMCount=Integer.toString(myMCount-1);
                    mCount.setText(mysMCount);
                    Toast.makeText(getApplicationContext(),"I'm going down to "+(myMCount-1)+"\n The Item is " + clickedCar.getName() ,Toast.LENGTH_SHORT).show();
                    int cnt = Integer.parseInt(mCount.getText().toString());
                    if (cnt>0)
                    {
                        System.out.println("count is"+cnt+"name is "+clickedCar.getName());

                        //c1[pns].setIname(clickedCar.getName());
                        //c1[pns].setCount(cnt);
                        c2.setIname(clickedCar.getName());
                        c2.setCount(cnt);
                        myItem1.add(c2);
                    }
                    else {
                        System.out.println("Idhu else guru count is" + cnt + "name is " + clickedCar.getName());
                    }
                }
            });
            mPlus.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view)
                {
                    int myPCount = Integer.parseInt(mCount.getText().toString());
                    String mysPCount=Integer.toString(myPCount+1);
                    mCount.setText(mysPCount);
                    Toast.makeText(getApplicationContext(),"im up to "+(myPCount+1)+"\n The Item is " + clickedCar.getName() ,Toast.LENGTH_SHORT).show();
                    int cnt = Integer.parseInt(mCount.getText().toString());
                    if (cnt>0)
                    {
                        System.out.println("count is"+cnt+"name is "+clickedCar.getName());
                        c2.setIname(clickedCar.getName());
                        c2.setCount(cnt);
                        myItem1.add(c2);
                    }
                    else {
                        System.out.println("Idhu else guru count is" + cnt + "name is " + clickedCar.getName());
                    }
                }
            });
            //µSystem.out.println("Name: "+c1[1].getName()+"Count :"+c1[1].getCount() + " Position : "+position);
            // Find the car to work with.
            Cat_item currentCar = myItem.get(position);

            // Fill the view
            ImageView imageView = (ImageView)itemView.findViewById(R.id.item_icon);
            imageView.setImageResource(currentCar.getIconID());

            // Make:
            TextView makeText = (TextView) itemView.findViewById(R.id.item_txtMake);
            makeText.setText(currentCar.getName());
            System.out.println("Adding");


            return itemView;
        }

    }
}