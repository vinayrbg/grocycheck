package savi.asu.picknpack;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

/**
 * Created by srisa on 4/21/2017.
 */

public class RecAct extends AppCompatActivity {



    protected ListView lv;
    protected ListAdapter adapter;
    SQLiteDatabase db;
    Cursor cursor;
    EditText et_db;

    @SuppressWarnings("deprecation")
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipes);

        db = (new DB_R(this)).getWritableDatabase();
        lv = (ListView) findViewById(R.id.lv);
        et_db = (EditText) findViewById(R.id.et);
        if(getSupportActionBar()!=null)
        {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        try {
            cursor = db.rawQuery("SELECT * FROM recep ORDER BY name ASC", null);
            adapter = new SimpleCursorAdapter(this, R.layout.isi_lv, cursor,new String[] { "name", "items", "img" }, new int[] {
                    R.id.tv_name, R.id.tvItems, R.id.imV });
            lv.setAdapter(adapter);
            lv.setTextFilterEnabled(true);
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View v,
                                        int position, long id) {
                    detail(position);

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home)
            startActivity(new Intent(this,MainActivity.class));
        return super.onOptionsItemSelected(item);
    }
    @SuppressWarnings("deprecation")
    public void search_db(View v) {
        String edit_db = et_db.getText().toString();
        if (!edit_db.equals("")) {
            try {
                cursor = db.rawQuery("SELECT * FROM recep WHERE name LIKE ?",
                        new String[] { "%" + edit_db + "%" });
                adapter = new SimpleCursorAdapter(
                        this,
                        R.layout.isi_lv,
                        cursor,
                        new String[] { "name", "items", "img" },
                        new int[] { R.id.tv_name, R.id.tvItems, R.id.imV });
                if (adapter.getCount() == 0) {
                    Toast.makeText(
                            this,
                            "Search '" + edit_db
                                    + "' Not found", Toast.LENGTH_SHORT).show();
                } else {
                    lv.setAdapter(adapter);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                cursor = db.rawQuery("SELECT * FROM recep ORDER BY name ASC",
                        null);
                adapter = new SimpleCursorAdapter(
                        this,
                        R.layout.isi_lv,
                        cursor,
                        new String[] { "name", "items", "img" },
                        new int[] { R.id.tv_name, R.id.tvItems, R.id.imV });
                lv.setAdapter(adapter);
                lv.setTextFilterEnabled(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void detail(int position) {
        int im = 0;
        String _id = "";
        String name = "";
        String items = "";
        String directions = "";
        if (cursor.moveToFirst()) {
            cursor.moveToPosition(position);
            im = cursor.getInt(cursor.getColumnIndex("img"));
            name = cursor.getString(cursor.getColumnIndex("name"));
            items = cursor.getString(cursor.getColumnIndex("items"));
            directions = cursor.getString(cursor.getColumnIndex("directions"));
        }

        Intent iIntent = new Intent(this, DB_P.class);
        iIntent.putExtra("dataIM", im);
        iIntent.putExtra("dataName", name);
        iIntent.putExtra("dataItems", items);
        iIntent.putExtra("dataDirections", directions);
        setResult(RESULT_OK, iIntent);
        startActivityForResult(iIntent, 99);
    }

}

