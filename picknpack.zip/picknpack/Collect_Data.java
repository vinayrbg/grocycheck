package savi.asu.picknpack;

/**
 * Created by srisa on 5/8/2017.
 */

public class Collect_Data {

    private String iname;
    private int count;

    public void setIname(String iname) {
        this.iname = iname;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getName() {
        return iname;
    }
    public int getCount() {
        return count;
    }
}