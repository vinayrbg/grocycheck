package savi.asu.picknpack;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import savi.asu.picknpack.R;

/**
 * Created by srisa on 3/13/2017.
 */

public class Setttings extends android.support.v4.app.Fragment {

    View myView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        myView=inflater.inflate(R.layout.settings, container, false);
        return myView;
    }
}
