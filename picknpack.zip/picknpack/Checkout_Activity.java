package savi.asu.picknpack;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

/**
 * Created by srisa on 5/8/2017.
 */

public class Checkout_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout_);
        TextView textout = (TextView) findViewById(R.id.textView3);
        TextView textout1 = (TextView) findViewById(R.id.textView4);
        ImageButton hme = (ImageButton) findViewById(R.id.imageButton);
        hme.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), MainActivity.class);
                startActivityForResult(myIntent, 0);
            }
        });
        textout.setText(MainActivity.listname);
        System.out.println("The size of myitem1 "+SubActivity1.myItem1.size());
        for(int i=0;i<SubActivity1.myItem1.size();i++) {
            System.out.println("The value of myitem1 " + SubActivity1.myItem1.get(i).getName());
            textout1.setText(SubActivity1.myItem1.get(i).getName()+"   "+ SubActivity1.myItem1.get(1).getCount());
        }
        //textout1.setText(SubActivity1.myItem1.get(1).getName() +"   "+ SubActivity1.myItem1.get(1).getCount());
    }
    }
