package savi.asu.picknpack;

/**
 * Created by srisa on 5/8/2017.
 */

public class Cat_item {

        private String name;
        // private int year;
        private int iconID;

        public Cat_item(String name, int iconID) {
            super();
            this.name = name;
            //   this.year = year;
            this.iconID = iconID;
            //   this.np = np;
//        this.condition = condition;
        }

        public String getName() {
            return name;
        }

        public int getIconID() {
            return iconID;
        }
    }


