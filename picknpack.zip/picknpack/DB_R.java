package savi.asu.picknpack;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by srisa on 5/12/2017.
 */

public class DB_R extends SQLiteOpenHelper {

    final static String DB_name = "db_recep";
    //final static String DB_name= "db_list";

    public DB_R(Context context) {
        super(context, DB_name, null, 1);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE IF NOT EXISTS recep(_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, items TEXT, directions TEXT, img BLOB)";
        db.execSQL(sql);
        //String sql1= " CREATE TABLE IF NOT EXISTS list(id_ INTEGER PRIMARY KEY AUTOINCREMENT, item_name TEXT, imag BLOB");
        //db.execSQL(sql1);


        ContentValues values = new ContentValues();
        values.put("_id", "1");
        values.put("name", "Tomato Curry");
        values.put("items", "Tomatoes \n" +
                "Onion \n" + "Peppers \n" + "turmeric \n" + " Garam Masala \n" + " Coriander \n" + "Cumin \n");
        values.put("directions", "1/4 cup vegetable oil (or ghee) \n" +
                "1 medium onion, finely minced \n" +
                "Sea salt \n" +
                "3 tablespoons finely grated ginger  \n" +
                "4 garlic cloves, finely grated \n" +
                "1 teaspoon garam masala  \n" +
                "1 teaspoon ground turmeric  \n" +
                "1 teaspoon ground coriander  \n" +
                "1 teaspoon ground cumin  \n" +
                "1/4 to 1 teaspoon cayenne pepper (to taste) \n" +
                "Seeds from 4 cardamom pods \n" +
                "One 15-ounce can crushed tomatoes \n" +
                "1/2 cup water ");
        values.put("img", R.drawable.tomatocurry);
        db.insert("recep", "_id", values);

        values.put("_id", "2");
        values.put("name", "Fajitas");
        values.put("items", "Lemon juice \n" +
                "Onion \n" + "Peppers \n" + "turmeric \n" + " Garam Masala \n" + " Coriander \n" + "Cumin \n");
        values.put("directions", "4 tablespoons canola oil, divided \n" +
                "2 tablespoons lemon juice \n" +
                "1-1/2 teaspoons seasoned salt \n" +
                "1-1/2 teaspoons dried oregano \n" +
                "1-1/2 teaspoons ground cumin \n" +
                "1 teaspoon garlic powder \n" +
                "1/2 teaspoon chili powder \n" +
                "1/2 teaspoon paprika \n" +
                "1/2 teaspoon crushed red pepper flakes, optional \n" +
                "1-1/2 pounds boneless skinless chicken breast, cut into thin strips \n" +
                "1/2 medium sweet red pepper, julienned \n" +
                "1/2 medium green pepper, julienned \n" +
                "4 green onions, thinly sliced \n" +
                "1/2 cup chopped onion \n" +
                "6 flour tortillas (8 inches), warmed \n" +
                "Shredded cheddar cheese, taco sauce, salsa, guacamole and sour cream ");
        values.put("img", R.drawable.fajitas);
        db.insert("recep", "_id", values);

        values.put("_id", "3");
        values.put("name", "BlackBean Rice");
        values.put("items", "Beans \n" +
                "Onion \n" + "Peppers \n" + "turmeric \n" + " Garam Masala \n" + " Coriander \n" + "Cumin \n");
        values.put("directions", "1 teaspoon olive oil\n" +
                "1 large onion, chopped finely\n" +
                "1 red pepper, diced\n" +
                "3 cloves garlic, minced\n" +
                "3⁄4 cup uncooked white rice\n" +
                "1 1⁄2 cups vegetable broth, see my recipe posted or use store bought\n" +
                "1 teaspoon ground cumin\n" +
                "1 teaspoon curry powder\n" +
                "1⁄2 teaspoon cayenne pepper\n" +
                "4 cups canned black beans, drained");
        values.put("img", R.drawable.blackbean_rice);
        db.insert("recep", "_id", values);

        values.put("_id", "4");
        values.put("name", "Chicken Biryani");
        values.put("items", " Chicken \n" + "Tomatoes \n" +
                "Onion \n" + "Peppers \n" + "turmeric \n" + " Garam Masala \n" + " Coriander \n" + "Cumin \n");
        values.put("directions", "300g basmati rice\n" +
                "25g butter\n" +
                "1 large onion, finely sliced\n" +
                "1 bay leaf\n" +
                "3 cardamom pods\n" +
                "1 small cinnamon stick\n" +
                "1 teaspoon turmeric\n" +
                "4 chicken breasts, sliced\n" +
                "4 tablespoons curry paste\n" +
                "85g raisins\n" +
                "850 ml chicken stock\n" +
                "coriander, chopped\n" +
                "sliced almonds");
        values.put("img", R.drawable.chicken_biryani);
        db.insert("recep", "_id", values);

        values.put("_id", "4");
        values.put("name", "Macaroni Cheese");
        values.put("items", "Tomatoes \n" +
                "Onion \n" + "Peppers \n" + "turmeric \n" + " Garam Masala \n" + " Coriander \n" + "Cumin \n");
        values.put("directions", "500g macaroni\n" +
                "1 tablespoon olive oil\n" +
                "2 onions, diced\n" +
                "1 zucchini, grated\n" +
                "1 red capsicum, diced\n" +
                "1 green capsicum, diced\n" +
                "4 cups sliced mushrooms (roughly, one brown mushroom bag full)\n" +
                "2(440 g) cans condensed tomato soup\n" +
                "1⁄2 teaspoon cayenne pepper (or to taste)\n" +
                "500g grated low-fat cheese\n" +
                "500g grated low-fat cheese, extra");
        values.put("img", R.drawable.macaroni_cheese);
        db.insert("recep", "_id", values);

        values.put("_id", "5");
        values.put("name", "Egg bhurji");
        values.put("items", "Eggs \n" + "Tomatoes \n" +
                "Onion \n" + "Peppers \n" + "turmeric \n" + " Garam Masala \n" + " Coriander \n" + "Cumin \n");
        values.put("directions", "2 tablespoons vegetable oil\n" +
                "1 medium onion, chopped fine\n" +
                "2 medium tomatos chopped fine\n" +
                "3 green chilli peppers slit lengthwise \n" +
                "2 teaspoons ginger-garlic paste\n" +
                "1 teaspoon red chilli powder\n" +
                "1/2 teaspoon turmeric powder\n" +
                "4 eggs whisked lightly\n" +
                "Salt\n" +
                "2 teaspoons butter divided\n" +
                "1/4 cup chopped coriander leaves divided");
        values.put("img", R.drawable.eggbhurji);
        db.insert("recep", "_id", values);

        values.put("_id", "6");
        values.put("name", "Kakori Kebab");
        values.put("items", "Black Peppercorns \n" +
                "Onion \n" + "Peppers \n" + "turmeric \n" + " Garam Masala \n" + " Coriander \n" + "Cumin \n");
        values.put("directions", "2-3 pieces of Green Cardamom (Hari eliachi) \n" +
                "2-3 pieces of Black Peppercorns (Sabut Kali mirch) \n" +
                "4-5 pieces of Cloves (Laung) \n" +
                "2 blades of Mace (Javitri) \n" +
                "10-15 pieces of Black peppercons \n" +
                "2 teaspoon Poppy seeds (Khus Khus) \n" +
                "1/2 teaspoon Shahi Jeera (caraway seeds) \n" +
                "500 gms Minced Chicken or 1 LB \n" +
                "1/2 cup Desiccated unsweetend Cococut \n" +
                "1/2 cup Powdered Khoya/Mawa \n" +
                "1/4 cup Raw Papaya Paste \n" +
                "2 tablespoon Fresh cream \n" +
                "1 teaspoon Cashew Paste \n" +
                "1 teaspoon Crushed ginger \n" +
                "1 teaspoon Rose water \n" +
                "1 tablespoon Onion paste \n" +
                "1/4- 1/2 teaspoon Nutmeg powder (Jaiphel) \n" +
                "1/2 teaspoon Red chili powder \n" +
                "1 teaspoon Garlic powder \n" +
                "1/2 - 3/4 teaspoon Garam Masala Powder (optional) \n" +
                "1/4 teaspoon White pepper powder \n" +
                "Few strands of Saffron \n" +
                "Salt to taste \n" +
                "2 teaspoon Oil to shape kebabs \n" +
                "1-2 tablespoon Oil to cook Kebabs ");
        values.put("img", R.drawable.kakori_kebab);
        db.insert("recep", "_id", values);

        values.put("_id", "7");
        values.put("name", "Paneer Butter Masala");
        values.put("items", "Paneer \n" +
                "Onion \n" + "Peppers \n" + "turmeric \n" + " Garam Masala \n" + " Coriander \n" + "Cumin \n");
        values.put("directions", "250gms Paneer \n" +
                "2 medium onions \n" +
                "3/2 teasppons chopped ginger \n" +
                " 3-4 Garlic Cloves\n" +
                " 3 medium tomatoes\n" +
                "6-8 cashew nuts\n" +
                "1/2 cup full fat milk\n" +
                " 2 teaspoons kasur methi\n" +
                " 1 tablespoon coriander powder\n" +
                "2 table spoons butter\n" +
                "2 table spoons Oil\n" +
                "Salt");
        values.put("img", R.drawable.pbm);
        db.insert("recep", "_id", values);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS recep");
        onCreate(db);

    }

}



